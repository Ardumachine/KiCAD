This package differs from all the other Freeroute source archives in that this fork runs in Java7. This only needed a couple dozen changes, but hopefully this is helpful.
This root directory is a netbeans project. Look in the freeroute/ directory for the source.
Binaries are available in the dist/ directory. FreeRoute_pack.jar contains the JavaHelp (jh.jar) embededded so can operate standalone.
FreeRoute.jar requires lib/jh.jar. 
The package_freeroute_jar.sh script performs the packing; I'm sure there's a far more elegent way to do this, but I'm not familiar with java, so this is it unless someone can help me out.
All credits to Alfons Wirtz for actually writing this great piece of software.

