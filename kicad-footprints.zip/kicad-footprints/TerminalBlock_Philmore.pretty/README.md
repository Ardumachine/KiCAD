# TerminalBlock_Philmore.pretty

Philmore (http://www.philmore-datak.com/) terminal block footprints.

(Most of) These footprints have been script-generated with a python script available https://github.com/pointhi/kicad-footprint-generator/scripts/TerminalBlock_Philmore .