# TerminalBlock.pretty

This repository contains footprints for various terminal blocks that do not have their own manufacturer-specific repository.

Existing manufacturer-specific libraries are:

* ../TerminalBlock_4UCON.pretty
* ../TerminalBlock_MetzConnect.pretty
* ../TerminalBlock_Phoenix.pretty
* ../TerminalBlock_Philmore.pretty
* ../TerminalBlock_RND.pretty
* ../TerminalBlock_WAGO.pretty
* ../TerminalBlock_Dinkle.pretty
* ...
