# TerminalBlock_WAGO.pretty

WAGO (http://www.wago.de/) terminal block footprints 

(Most of) These footprints have been script-generated with a python script available https://github.com/pointhi/kicad-footprint-generator/scripts/TerminalBlock_WAGO .