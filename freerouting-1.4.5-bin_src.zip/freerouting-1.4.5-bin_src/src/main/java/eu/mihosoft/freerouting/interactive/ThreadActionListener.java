package eu.mihosoft.freerouting.interactive;

public interface ThreadActionListener {
    void autorouterStarted();
    void autorouterAborted();
    void autorouterFinished();
}
