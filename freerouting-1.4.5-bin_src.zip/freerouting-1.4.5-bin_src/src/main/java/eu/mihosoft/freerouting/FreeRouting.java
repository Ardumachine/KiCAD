package eu.mihosoft.freerouting;

public class FreeRouting {
}
